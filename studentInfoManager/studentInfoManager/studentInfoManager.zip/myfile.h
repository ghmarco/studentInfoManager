#ifndef MYFILE_H_
#define MYFILE_H_


#include "base.h"

int readFromFile(char *fname, pstuInfo h);

int writeToFile(char *fname, pstuInfo h);

#endif // !MYFILE_H